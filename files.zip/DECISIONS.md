# DECISIONS.md

The honesty ledger. Every place this simulation departs from real Google Ads,
what the departure is, and why.

Its purpose: when you use this simulator to learn, you must be able to tell the
difference between **how Google Ads works** and **how this model works**. Without
this file you will eventually mistake a simplification for a fact.

**Status key**
`FIXED` resolved in spec v0.2 · `OPEN` known gap, not yet addressed ·
`WONTFIX` deliberate permanent simplification

---

## A. Quality Score

### A1. Reported Quality Score is not an auction input — `FIXED v0.2`
**Real:** Google states plainly that Quality Score is not an input in the ad
auction; it is a diagnostic tool. What *does* enter the auction are real-time
quality signals computed per individual query, using context the report never
shows. Those signals sit in the denominator of the actual CPC calculation.

**Sim v0.1:** one 1–10 number was multiplied into ad rank. Wrong.

**Sim v0.2:** split into `qualitySignal` (continuous, per-query, in the auction)
and `reportedScore` (1–10, lagging, output only, never read by the engine).

**The line to hold onto:** quality *is* in the auction; the number on your screen
is not that number.

### A2. Components are three-level, not 1–10 — `FIXED v0.2`
**Real:** expected CTR, ad relevance and landing page experience are reported only
as below average / average / above average. The 1–10 scale exists solely at the
overall keyword level.

**Sim v0.2:** `reportedScore` returns three-level ratings only. The 1–10 score is
derived from them via `RATING_TO_SCORE_TABLE`, which is invented.

### A3. Component weights are invented — `OPEN`
**Real:** Google publishes no formula and no weights.

**Sim:** `QUALITY_WEIGHTS = { 0.5, 0.3, 0.2 }`. Tagged `ESTIMATED`. Third-party
analyses disagree with this and with each other; one puts expected CTR near 39%,
equal to landing page and double ad relevance.

**Only the ordering has a basis.** See A4. The numbers do not.

### A4. Why expected CTR plausibly leads — *this part is real theory*
Google's expected revenue from an impression is price × probability of click.
Ranking by bid × predicted CTR is the arrangement that maximises revenue per
search. So click probability belongs in the rank multiplier for a hard economic
reason, not a user-experience one.

Ad relevance and landing page experience protect long-run user trust, which does
not appear in single-impression revenue. That is a principled reason to expect
them to weigh less — and it yields no number.

### A5. Quality Score is backward-looking and exact-match based — `FIXED v0.2`
**Real:** calculated from roughly 90 days of history on exact searches of your
keyword, relative to other advertisers who appeared for the same search.
Consequence: **changing match types alone will not move Quality Score.**

**Sim v0.2:** 13-round trailing window, exact-query impressions only, with a test
asserting match-type changes do not move it.

---

## B. Auction and pricing

### B1. Ad rank threshold is a constant — `OPEN`
**Real:** thresholds vary by query, context and position. This is why CPCs
sometimes jump with no visible cause.
**Sim:** `AD_RANK_FLOOR`, one number. `INVENTED`.

### B2. Extensions are a flat multiplier — `OPEN`
**Real:** Google models the expected impact of extensions and formats, varying by
ad, query and position.
**Sim:** `EXTENSIONS_IMPACT = 0.1`, applied uniformly. `INVENTED`.

### B3. Position CTR multipliers are estimates — `OPEN`
**Sim:** `[1, 0.62, 0.42, 0.30, 0.12, 0.08, 0.06]`. Directionally sound, not
sourced. `ESTIMATED`.

### B4. Slot count is fixed — `WONTFIX`
**Real:** varies by query and device; sometimes zero ads show.
**Sim:** always 7 slots, 4 above organic.

### B5. The SERP contains only ads — `WONTFIX`
**Real:** shopping carousels, local packs, AI overviews and organic results
compete for the same attention and change effective CTR.

---

## C. Competitors

### C1. Competitors never react — `FIXED v0.2`
**Sim v0.1:** static bids forever.
**Sim v0.2:** competitors are full `Advertiser` objects with per-round decisions
from rule-based or Claude-backed policies.

### C2. Ad copy graded in isolation — `OPEN`
**Real:** expected CTR is relative to the other ads actually in the auction.
**Sim:** the grader sees one ad at a time. Spec 7.4 requires it to know about
rival trademarks, which pulls in the same direction. Candidate for v0.3.

### C3. Information asymmetry — `FIXED v0.2`
**Real:** Auction Insights names competitors by domain and gives six metrics.
Ads Transparency Center makes their creative public. Bids, budgets, costs,
quality and conversions are never visible.
**Sim v0.2:** `getPublicView` enforces exactly this split.

**Trap preserved deliberately:** overlap rate is not market share and is not a
measure of spend. It is the most misread number in the report.

---

## D. Budget and bidding

### D1. Budget model was outdated — `FIXED v0.2`
**Sim v0.1:** spend accumulated from midnight and stopped dead. That is
accelerated delivery, which Google removed in 2019.
**Sim v0.2:** paced delivery, up to 2× daily budget on any single day, capped
across the round.

### D2. Smart Bidding was an oracle — `FIXED v0.2`
**Sim v0.1:** Target CPA and Target ROAS used the *true* hourly conversion rate.
Never wrong. This badly flattered automation.
**Sim v0.2:** estimates drawn around observed history, error shrinking with
conversion volume, plus a learning period after every change.

### D3. Quality improvements were free sliders — `FIXED v0.2`
**Sim v0.1:** drag a slider from 4 to 9, costs drop instantly.
**Sim v0.2:** you write real ad copy and Claude grades it. Improving quality now
costs what it costs in life: the work of writing something good, with no guarantee.

---

## E. Missing entirely

### E1. Queries, match types, negatives — `FIXED v0.2`
The largest v0.1 gap. You do not buy keywords; you buy matches between your
keywords and unpredictable human queries. Now modelled, including
`intent: 'irrelevant'` queries that exist to be wasted money.

### E2. Account structure — `WONTFIX for v0.2`
No devices, geography, audiences, or multiple campaigns. One market.

### E3. Multi-day state — `FIXED v0.2`
Twelve weekly rounds with persistent state.

---

## F. Statistics and economics

### F1. No noise — `FIXED v0.2`
**Real:** accounts are violently noisy at low volume. Telling signal from noise,
and not optimising on twelve clicks, is a core skill.
**Sim v0.2:** `mode: 'sampled'` for play, `mode: 'expected'` for smooth feedback
while adjusting settings.

### F2. Conversions were instantaneous — `FIXED v0.2`
**Real:** attribution windows, lag of days or weeks. This lag is *why* bid
strategies look broken when checked too early.
**Sim v0.2:** `pendingConversions` queue; reports keyed by click round and revised
when late conversions land.

### F3. Order value was a fixed number — `FIXED v0.2`
Now a distribution via `aovSpread`, which is what ROAS bidding exists to predict.

### F4. Profit ignores lifetime value — `OPEN`
**Real:** many advertisers rationally lose money on the first order.
**Sim:** profit is margin on net revenue minus cost, single purchase only. For
athleisure this matters less than it would for a subscription, but repeat purchase
is real and unmodelled.

### F5. Demand and intent curves are invented — `OPEN`
`DAY_OF_WEEK_CURVE` and `HOUR_PROFILES` are hand-drawn. The *shape* of the lesson
— demand peak and intent peak do not coincide — is sound. These particular numbers
are illustrative only and should never be quoted as facts about any industry.

### F6. Return rate is a single estimate — `OPEN`
`ATHLEISURE_RETURN_RATE = 0.24`. Athleisure return rates are genuinely high and
genuinely variable. One number for a whole category is a simplification.

---

## G. Things the simulation knows that reality cannot

### G1. Exact counterfactuals — *by design*
`missedToBudget` is computed by re-running the round with unlimited budget and
diffing. Because this is a simulation, that counterfactual is exact.

Google can only **estimate** this: lost impression share as a percentage, and
estimated additional clicks in Recommendations. It never observes the
counterfactual.

**The UI must label this.** Knowing what kind of number you are looking at — an
observation, an estimate, or an impossibility — is itself part of the education.

---

## H. What the simulation gets right

Recorded because the list above is long and the payload matters:

1. **Second-price mechanics.** You pay what is needed to beat the advertiser below
   you, not your bid.
2. **Quality as a price discount**, not a tiebreaker. Better ads cost less.
3. **Impression share splitting losses** into rank problems and budget problems,
   which have opposite fixes.
4. **Demand peak and intent peak do not coincide**, which is where dayparting
   earns its money.
5. **Broad match degrades quality as well as wasting spend**, because a distant
   query lowers `queryKeywordFit` and therefore ad rank on that query.
6. **Impression share can fall while impressions rise** when you broaden a
   keyword, because the denominator grows faster than the numerator.

---

## Maintenance rule

Every time you or Claude Code picks a number with no source, add it here before
committing. If it is not in this file, it is not a decision — it is an accident.
