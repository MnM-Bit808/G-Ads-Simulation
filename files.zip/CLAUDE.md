# CLAUDE.md

Project instructions. Read at the start of every session.

## What this is

A Google Ads search auction simulator, built to be played as a learning tool for
paid search advertising. Vertical: athleisure and gym clothing, D2C, India.

Its value depends entirely on being **honest about what it models**. A simulator
that teaches something false is worse than no simulator, because the person cannot
tell the difference. Accuracy outranks features here.

## Read before writing any code

- `ENGINE_SPEC_v0.2.md` — the specification. It is the source of truth.
- `DECISIONS.md` — every departure from real Google Ads and why.

If the spec and your instinct disagree, say so and ask. Do not silently deviate.

## Working with me

I am relatively new to development. Explain technical concepts in plain language
when they come up. I am building this to understand it, so a working file I cannot
follow is a failure even if the tests pass.

- **Plan before code.** For anything beyond a trivial edit, tell me the approach
  first and wait.
- **Ask rather than assume.** If the spec is ambiguous, say which part and what
  the options are. Guessing silently is the main failure mode I am trying to avoid.
- **One module at a time.** Do not build ahead.
- **Push back.** If something in the spec is wrong or will not work, say so.

## Hard rules

These come from the spec and are not negotiable without changing the spec first.

1. **The engine is pure.** No network calls, no clocks, no global state, no
   unseeded randomness inside `engine/`.
2. **Claude calls live in `agents/` only.** The full test suite must pass with no
   network access.
3. **Money is integer paise.** Never floating point. Format only at display.
4. **Nothing in `engine/` may read `reportedScore`.** It is output only.
5. **`getPublicView` is the only route to another advertiser's data**, and it
   exposes id, name, domain and ad creative. Nothing else.
6. **One advertiser type.** No privileged player path anywhere.
7. **Every unsourced number goes in `constants.js`** with a provenance tag
   (`DOCUMENTED` / `ESTIMATED` / `INVENTED`) and an entry in `DECISIONS.md`.

## Workflow

Tests first, then implementation, then run them and iterate until green.

```bash
npm test                 # vitest
npm test -- auction      # one file
npm run dev              # UI
```

Commit after every green test run. Small commits, present tense, one concern each.

## Conventions

- ES modules, `.js`, no TypeScript for now.
- Named exports. No default exports outside `ui/`.
- Pure functions take dependencies as arguments; nothing reaches for a module-level
  singleton, `rng` least of all.
- JSDoc on every exported function: what it does, units, and any invariant it
  assumes.
- Comments explain *why*, never *what*.

## Build order

1. `constants.js`, `money.js`, `rng.js`
2. `auction.js` + tests
3. `matching.js` + tests
4. `quality.js` + tests
5. `strategies.js` + tests
6. `pacing.js`, `attribution.js`
7. `round.js` + tests
8. `insights.js` + tests
9. `agents/` — rule-based policies first, Claude-backed after
10. `ui/` last

## Known traps

- The v0.1 test asserting daily spend never exceeds the daily budget **should fail**
  once paced delivery lands. That failure is correct. Replace the test with the
  weekly cap assertion rather than patching around it.
- Improving ad copy must move `qualitySignal` immediately and leave
  `reportedScore` unchanged in the same round. If both move, the split is broken.
- Broadening a keyword must *lower* impression share while raising impressions. If
  it raises both, the eligibility denominator is wrong.
